"use client"
import { useEffect, useState } from "react";
import { Text, Avatar } from "@vibe/core";

interface User {
	id: string;
	name: string;
	email: string;
	photo_thumb_small: string;
}

export default function Home() {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
		const fetchUser = async () => {
			const res = await fetch("/api");
			const data = await res.json();
			setUser(data);
		};

		fetchUser();
	}, []);


  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-24">
      <Text className="text-4xl font-bold">Welcome to Vibe!</Text>
       
      {user ? (
        <div className="flex items-center mt-4">
          <Avatar 
          src={user.photo_thumb_small}
          onClick={function noRefCheck(){}}
          text={user.name}
          type="img"
          size="large" 
          />
          <div className="ml-4">
            <Text className="text-xl font-semibold">{user.name}</Text>
            <Text className="text-gray-500">{user.email}</Text>
          </div>
        </div>
      ) : (
        <Text className="mt-4">Loading user data...</Text>
      )}
    </div>
  );
}

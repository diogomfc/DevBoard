// app/api/user/route.ts
import { NextResponse } from "next/server";

export async function GET() {
	const token = process.env.MONDAY_API_TOKEN;

	if (!token) {
		return NextResponse.json(
			{ error: "Token não configurado" },
			{ status: 500 },
		);
	}

	try {
		const response = await fetch("https://api.monday.com/v2", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${token}`,
			},
			body: JSON.stringify({
				query: `
          {
            me {
              id
              name
              email
              photo_thumb_small
            }
          }
        `,
			}),
		});

		const result = await response.json();

		if (result?.data?.me) {
			return NextResponse.json(result.data.me);
		}

		return NextResponse.json(
			{ error: "Usuário não encontrado" },
			{ status: 404 },
		);
	} catch (error) {
		return NextResponse.json(
			{ error: "Erro ao buscar usuário" },
			{ status: 500 },
		);
	}
}
